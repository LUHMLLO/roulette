import{_ as r}from"./_layout.38454bf1.js";import{default as t}from"../entry/_layout.svelte.34334e82.js";export{t as component,r as universal};
