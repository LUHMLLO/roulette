import{default as t}from"../entry/error.svelte.c4b64e81.js";export{t as component};
