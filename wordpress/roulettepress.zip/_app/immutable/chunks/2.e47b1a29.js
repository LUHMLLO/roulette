import{default as t}from"../entry/_page.svelte.c66c499a.js";export{t as component};
