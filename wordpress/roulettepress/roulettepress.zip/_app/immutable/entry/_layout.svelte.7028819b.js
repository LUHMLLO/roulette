import{S as E,i as $,s as B,C,k as d,q as D,a as S,D as G,l as u,m as _,r as I,h as n,c as w,n as o,E as m,b as N,F as A,G as K,H as j,g as q,d as x}from"../chunks/index.f8ee0888.js";function O(h){let t,c,s,l,f,g,i,p,v,y;const b=h[1].default,e=C(b,h,h[0],null);return{c(){t=d("link"),c=d("link"),s=d("link"),l=d("style"),f=D(`:root {
            --bordRadius: var(--px--24);
            --inputBordRadius: var(--bordRadius);
            --buttonBordRadius: var(--bordRadius);

            --fontFamily: "Schibsted Grotesk", sans-serif;
            --headingFontFamily: "Bebas Neue", cursive;
            --buttonFontFamily: var(--fontFamily);

            --clr-first: var(--clr-gray--10);
            --clr-second: var(--clr-gray--9);
            --clr-third: var(--clr-gray--8);
            --clr-fourth: var(--clr-gray--7);

            --clr-accentLight: var(--clr-red--4);
            --clr-accent: var(--clr-red--5);
            --clr-accentDark: var(--clr-red--6);

            --clr-onAccent: var(--clr-gray--0);

            --clr-complementaryLight: var(--clr-amber--4);
            --clr-complementary: var(--clr-amber--5);
            --clr-complementaryDark: var(--clr-amber--6);

            --clr-onComplementary: var(--clr-first);

            --clr-heading: var(--clr-gray--0);
            --clr-content: var(--clr-gray--1);
            --clr-link: var(--clr-accent);
        }`),g=S(),i=d("grid"),p=d("container"),v=d("column"),e&&e.c(),this.h()},l(r){const a=G("svelte-1jwc9a2",document.head);t=u(a,"LINK",{rel:!0,href:!0}),c=u(a,"LINK",{href:!0,rel:!0}),s=u(a,"LINK",{href:!0,rel:!0}),l=u(a,"STYLE",{});var k=_(l);f=I(k,`:root {
            --bordRadius: var(--px--24);
            --inputBordRadius: var(--bordRadius);
            --buttonBordRadius: var(--bordRadius);

            --fontFamily: "Schibsted Grotesk", sans-serif;
            --headingFontFamily: "Bebas Neue", cursive;
            --buttonFontFamily: var(--fontFamily);

            --clr-first: var(--clr-gray--10);
            --clr-second: var(--clr-gray--9);
            --clr-third: var(--clr-gray--8);
            --clr-fourth: var(--clr-gray--7);

            --clr-accentLight: var(--clr-red--4);
            --clr-accent: var(--clr-red--5);
            --clr-accentDark: var(--clr-red--6);

            --clr-onAccent: var(--clr-gray--0);

            --clr-complementaryLight: var(--clr-amber--4);
            --clr-complementary: var(--clr-amber--5);
            --clr-complementaryDark: var(--clr-amber--6);

            --clr-onComplementary: var(--clr-first);

            --clr-heading: var(--clr-gray--0);
            --clr-content: var(--clr-gray--1);
            --clr-link: var(--clr-accent);
        }`),k.forEach(n),a.forEach(n),g=w(r),i=u(r,"GRID",{class:!0});var F=_(i);p=u(F,"CONTAINER",{});var R=_(p);v=u(R,"COLUMN",{class:!0});var L=_(v);e&&e.l(L),L.forEach(n),R.forEach(n),F.forEach(n),this.h()},h(){o(t,"rel","stylesheet"),o(t,"href","https://luisrmelo.vercel.app/css/main.css"),o(c,"href","https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap"),o(c,"rel","stylesheet"),o(s,"href","https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"),o(s,"rel","stylesheet"),o(v,"class","gap-32 align-center justify-center text-center"),o(i,"class","place-center h-100vh")},m(r,a){m(document.head,t),m(document.head,c),m(document.head,s),m(document.head,l),m(l,f),N(r,g,a),N(r,i,a),m(i,p),m(p,v),e&&e.m(v,null),y=!0},p(r,[a]){e&&e.p&&(!y||a&1)&&A(e,b,r,r[0],y?j(b,r[0],a,null):K(r[0]),null)},i(r){y||(q(e,r),y=!0)},o(r){x(e,r),y=!1},d(r){n(t),n(c),n(s),n(l),r&&n(g),r&&n(i),e&&e.d(r)}}}function T(h,t,c){let{$$slots:s={},$$scope:l}=t;return h.$$set=f=>{"$$scope"in f&&c(0,l=f.$$scope)},[l,s]}class M extends E{constructor(t){super(),$(this,t,T,O,B,{})}}export{M as default};
