import{default as t}from"../entry/_page.svelte.bcd5f30f.js";export{t as component};
