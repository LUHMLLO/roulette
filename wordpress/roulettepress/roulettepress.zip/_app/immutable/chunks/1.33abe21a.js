import{default as t}from"../entry/error.svelte.bad380b9.js";export{t as component};
